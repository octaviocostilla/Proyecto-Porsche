var form = document.getElementById('form')
form.addEventListener('Submit'),function(event){
event.preventDefault()
var username=document.getElementById('name').value
console.log(name)
var email=document.getElementById('email').value
console.log(email)
}